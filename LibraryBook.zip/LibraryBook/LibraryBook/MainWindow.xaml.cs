﻿using LibraryBook.Models;
using Microsoft.Win32;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Imaging;

namespace LibraryBook
{
    public partial class MainWindow : Window
    {
        private bool _menuVisible = true;
        private List<Book> _books;

        private readonly string _dataFile =
            Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),
                "LibraryBook",
                "books.json");

        public MainWindow()
        {
            InitializeComponent();
            LoadBooks();
        }

        // ===== ЗАГРУЗКА =====
        private void LoadBooks()
        {
            if (File.Exists(_dataFile))
            {
                _books = JsonConvert.DeserializeObject<List<Book>>(File.ReadAllText(_dataFile));
            }
            else
            {
                _books = new List<Book>
                {
                    new Book { Id=1, Title="Мастер и Маргарита", Author="Булгаков", Category="Роман", Price=500, Year=1967 },
                    new Book { Id=2, Title="Война и мир", Author="Толстой", Category="Классика", Price=650, Year=1869 }
                };
            }

            BooksList.ItemsSource = _books;
        }

        private void SaveBooks()
        {
            var dir = Path.GetDirectoryName(_dataFile);
            if (!Directory.Exists(dir))
                Directory.CreateDirectory(dir);

            File.WriteAllText(_dataFile, JsonConvert.SerializeObject(_books, Formatting.Indented));
        }

        // ===== ☰ МЕНЮ =====
        private void ToggleMenu_Click(object sender, RoutedEventArgs e)
        {
            var animation = new GridLengthAnimation
            {
                From = MenuColumn.Width,
                To = _menuVisible ? new GridLength(0) : new GridLength(180),
                Duration = new Duration(TimeSpan.FromMilliseconds(300))
            };

            MenuColumn.BeginAnimation(ColumnDefinition.WidthProperty, animation);
            _menuVisible = !_menuVisible;
        }

        // ===== 🔍 ПОИСК =====
        private void SearchButton_Click(object sender, RoutedEventArgs e)
        {
            TopSearchBox.Visibility =
                TopSearchBox.Visibility == Visibility.Visible
                ? Visibility.Collapsed
                : Visibility.Visible;

            if (TopSearchBox.Visibility == Visibility.Visible)
                TopSearchBox.Focus();
        }

        private void TopSearchBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            string text = TopSearchBox.Text.ToLower();

            BooksList.ItemsSource = _books.Where(b =>
                b.Title.ToLower().Contains(text) ||
                b.Author.ToLower().Contains(text) ||
                b.Category.ToLower().Contains(text) ||
                b.Year.ToString().Contains(text) ||
                b.Price.ToString().Contains(text)
            ).ToList();
        }

        // ===== ВЫБОР КНИГИ =====
        private void BooksList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Book book = BooksList.SelectedItem as Book;
            if (book == null) return;

            InfoText.Text = book.ReaderInfo;

            if (!string.IsNullOrEmpty(book.BookImagePath))
                BookImage.Source = new BitmapImage(new Uri(book.BookImagePath));

            if (!string.IsNullOrEmpty(book.AuthorImagePath))
                AuthorImage.Source = new BitmapImage(new Uri(book.AuthorImagePath));
        }

        // ===== 📷 КАРТИНКИ =====
        private void SelectBookImage_Click(object sender, RoutedEventArgs e)
        {
            Book book = BooksList.SelectedItem as Book;
            if (book == null) return;

            var dlg = new OpenFileDialog();
            if (dlg.ShowDialog() == true)
            {
                book.BookImagePath = dlg.FileName;
                BookImage.Source = new BitmapImage(new Uri(dlg.FileName));
                SaveBooks();
            }
        }

        private void SelectAuthorImage_Click(object sender, RoutedEventArgs e)
        {
            Book book = BooksList.SelectedItem as Book;
            if (book == null) return;

            var dlg = new OpenFileDialog();
            if (dlg.ShowDialog() == true)
            {
                book.AuthorImagePath = dlg.FileName;
                AuthorImage.Source = new BitmapImage(new Uri(dlg.FileName));
                SaveBooks();
            }
        }
    }
}
