﻿namespace LibraryBook.Models
{
    public class Book
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Author { get; set; }
        public string Category { get; set; }
        public decimal Price { get; set; }
        public int Year { get; set; }

        // пути к картинкам (У КАЖДОЙ КНИГИ СВОИ)
        public string BookImagePath { get; set; }
        public string AuthorImagePath { get; set; }

        // инфо читателя
        public string ReaderInfo =>
            $"ID книги: {Id} | Иванов Иван Иванович | Тел: +7 (900) 123-45-67";
    }
}
